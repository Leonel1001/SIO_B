# Simulação de Veículo Autónomo com A\*

Este projeto simula um robô móvel autónomo (AMR) a navegar num armazém 2D utilizando o algoritmo de planeamento de percurso A\* e apresenta uma visualização passo a passo do processo de busca.

## Estrutura dos Ficheiros

* `mapa.py`            : Geração do mapa do armazém (20×20) com prateleiras e passagens.
* `pathfinder_vis.py`  : Implementação de A\* passo a passo como gerador, fornecendo estados para visualização.
* `simular_vis.py`     : Interface gráfica (Pygame) que mostra a expansão do A\* (conjuntos aberto/fechado, nó atual, caminho) e, posteriormente, anima o robô seguindo o percurso.

## Dependências

* Python 3.7 ou superior
* Pygame

## Instalação

No terminal, navega até à pasta do projeto e executa:

```bash
# (Opcional) Cria um ambiente virtual
python3 -m venv venv
source venv/bin/activate      # macOS/Linux
venv\Scripts\activate       # Windows

# Atualiza o pip
pip install --upgrade pip

# Instala o Pygame
pip install pygame
```

## Execução

1. Assegura-te de que os ficheiros `mapa.py`, `pathfinder_vis.py` e `simular_vis.py` estão na mesma pasta.
2. Executa o simulador:

```bash
python simular_vis.py
```

3. Na janela do Pygame:

   * Clica numa célula livre (branca) para definir o destino (verde).
   * Observa a busca A\* passo a passo:

     * **Azul**: Conjunto fechado (nós já explorados)
     * **Amarelo**: Conjunto aberto (fronteira de exploração)
     * **Vermelho**: Nó atualmente a ser processado
     * **Verde**: Construção gradual do caminho ótimo
   * Assim que a busca termina, o robô (círculo vermelho) percorre automaticamente o caminho ótimo até ao destino.

## Descrição do Algoritmo A\*

O algoritmo A\* é uma técnica de IA para encontrar o percurso de custo mínimo entre dois pontos num grafo ou grelha com obstáculos.

* **Estados**: Cada célula livre do mapa.
* **Ações**: Movimentos para cima, baixo, esquerda ou direita (custo = 1).
* **g(n)**: Custo acumulado do ponto inicial até ao nó n.
* **h(n)**: Heurística — estimativa do custo do nó n até ao destino. Utiliza-se aqui a distância de Manhattan:

  $$
    h(n) = |n.x - goal.x| + |n.y - goal.y|
  $$
* **f(n)**: Função de avaliação do nó n:

  $$
    f(n) = g(n) + h(n)
  $$

  O algoritmo escolhe o nó com menor valor de f(n) para expandir.

### Passos principais:

1. Inserir o nó inicial no **Conjunto Aberto**.
2. Enquanto o **Conjunto Aberto** não estiver vazio:

   * Remover o nó com menor f(n) → **nó atual**.
   * Se for o destino, reconstruir o caminho através de `came_from`.
   * Caso contrário, mover o nó para o **Conjunto Fechado**.
   * Para cada vizinho livre:

     * Calcular custos g e f.
     * Se for um melhor caminho, atualizar `came_from` e inserir no **Conjunto Aberto**.
3. Reconstruir o caminho ótimo do destino até à origem.

## Personalizações

* **Dimensões do mapa**: Altera os valores em `mapa.py`.
* **Velocidade da animação (FPS)**: Modifica a variável `FPS` em `simular_vis.py`.
* **Heurística**: Podes substituir a heurística de Manhattan por outra função para diferentes comportamentos.

---

Desenvolvido por **Leonel Carvalho, Tiago Ribeiro e João Lemos** — *SIO\_GrupoB*
