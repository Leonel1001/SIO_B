import pygame
from simular import simular
from mapa_hard import criar_mapa_hard
from mapa_simple import criar_mapa


def selecionar_mapa_e_destino():
    pygame.init()

    # Configurações de exibição
    TAMANHO_CELULA = 30
    LARGURA = 800
    ALTURA = 600
    tela = pygame.display.set_mode((LARGURA, ALTURA))
    pygame.display.set_caption("Seleção de Mapa e Destino")
    font = pygame.font.SysFont(None, 24)

    # Opções de mapa
    mapas = {"Simples": criar_mapa(), "Complexo": criar_mapa_hard()}

    mapa_selecionado = None
    destino_selecionado = None
    nome_mapa = ""

    while True:
        tela.fill((255, 255, 255))

        # Desenhar menu de seleção de mapa
        if mapa_selecionado is None:
            texto = font.render("Selecione um mapa:", True, (0, 0, 0))
            tela.blit(texto, (50, 50))

            y = 100
            for nome in mapas.keys():
                rect = pygame.Rect(50, y, 200, 40)
                pygame.draw.rect(tela, (200, 200, 200), rect)
                texto = font.render(nome, True, (0, 0, 0))
                tela.blit(texto, (60, y + 10))
                y += 50
        else:
            # Desenhar mapa e instruções para selecionar destino
            texto = font.render(f"Mapa selecionado: {nome_mapa}", True, (0, 0, 0))
            tela.blit(texto, (50, 30))

            texto = font.render(
                "Clique no mapa para selecionar o destino da encomenda", True, (0, 0, 0)
            )
            tela.blit(texto, (50, 60))

            texto = font.render(
                "Pressione ENTER para confirmar ou ESC para voltar", True, (0, 0, 0)
            )
            tela.blit(texto, (50, 90))

            # Desenhar mapa
            for y in range(len(mapa_selecionado)):
                for x in range(len(mapa_selecionado[0])):
                    rect = pygame.Rect(50 + x * 20, 150 + y * 20, 20, 20)
                    cor = (0, 0, 0) if mapa_selecionado[y][x] == 1 else (255, 255, 255)
                    pygame.draw.rect(tela, cor, rect)
                    pygame.draw.rect(tela, (150, 150, 150), rect, 1)

            # Desenhar destino selecionado
            if destino_selecionado:
                y, x = destino_selecionado
                rect = pygame.Rect(50 + x * 20, 150 + y * 20, 20, 20)
                pygame.draw.rect(tela, (0, 255, 0), rect)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return None, None

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE and mapa_selecionado:
                    mapa_selecionado = None
                    destino_selecionado = None
                elif (
                    event.key == pygame.K_RETURN
                    and mapa_selecionado
                    and destino_selecionado
                ):
                    return mapa_selecionado, destino_selecionado

            if event.type == pygame.MOUSEBUTTONDOWN and mapa_selecionado:
                x, y = event.pos
                x = (x - 50) // 20
                y = (y - 150) // 20

                if 0 <= x < len(mapa_selecionado[0]) and 0 <= y < len(mapa_selecionado):
                    if mapa_selecionado[y][x] == 0:  # Só pode selecionar células livres
                        destino_selecionado = (y, x)

            if event.type == pygame.MOUSEBUTTONDOWN and mapa_selecionado is None:
                x, y = event.pos
                if 50 <= x <= 250:
                    for i, nome in enumerate(mapas.keys()):
                        if 100 + i * 50 <= y <= 140 + i * 50:
                            mapa_selecionado = mapas[nome]
                            nome_mapa = nome
                            break


if __name__ == "__main__":
    mapa, destino = selecionar_mapa_e_destino()
    if mapa and destino:
        simular(mapa, destino)
