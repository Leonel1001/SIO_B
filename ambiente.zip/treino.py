import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import random
from collections import deque
from mapa_dinamico import criar_mapa_dinamico
from mapa_hard import criar_mapa_hard
from mapa_simple import criar_mapa
from ambiente import Ambiente
import matplotlib.pyplot as plt

plt.ion()
fig, ax = plt.subplots()
(linha_recompensa,) = ax.plot([], [], label="Recompensa por episódio")
(linha_media,) = ax.plot([], [], label="Média móvel (50)")
ax.set_xlabel("Episódio")
ax.set_ylabel("Recompensa Total")
ax.set_title("Desempenho do Agente DQN")
ax.grid(True)
ax.legend()


class DQN(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(DQN, self).__init__()
        self.fc1 = nn.Linear(input_dim, 512)
        self.bn1 = nn.BatchNorm1d(512)
        self.drop1 = nn.Dropout(0.2)

        self.fc2 = nn.Linear(512, 256)
        self.bn2 = nn.BatchNorm1d(256)
        self.drop2 = nn.Dropout(0.2)

        self.fc3 = nn.Linear(256, output_dim)

    def forward(self, x):
        if x.dim() == 1:
            x = x.unsqueeze(0)  # Adiciona dimensão de batch
        if x.size(0) == 1:  # Se o batch size for 1, desative BatchNorm
            x = torch.relu(self.fc1(x))
            x = torch.relu(self.fc2(x))
        else:
            x = self.drop1(torch.relu(self.bn1(self.fc1(x))))
            x = self.drop2(torch.relu(self.bn2(self.fc2(x))))
        return self.fc3(x)


# Hiperparâmetros
gamma = 0.95
epsilon = 1.0
epsilon_min = 0.01
epsilon_decay = 0.99
batch_size = 128
target_update_freq = 200
memory_size = 50000
episodes = 3000
learning_rate = 0.0001
passos_por_episodio = 600

# Inicialização do ambiente
mapas = [criar_mapa()]
mapa = random.choice(mapas)
env = Ambiente(mapa)

# Verificação da dimensão de entrada
estado_teste = env.reset()
input_dim = len(estado_teste)
output_dim = 4

device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
policy_net = DQN(input_dim, output_dim).to(device)
target_net = DQN(input_dim, output_dim).to(device)
target_net.load_state_dict(policy_net.state_dict())
target_net.eval()

optimizer = optim.Adam(policy_net.parameters(), lr=learning_rate)
memory = deque(maxlen=memory_size)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(
    optimizer, "max", patience=50, factor=0.5
)


def escolher_acao(estado, epsilon):
    if random.random() < epsilon:
        return random.randint(0, output_dim - 1)
    estado_t = torch.FloatTensor(estado).to(device)
    with torch.no_grad():
        policy_net.eval()  # Coloca o modelo em modo de avaliação
        q_vals = policy_net(estado_t)
        policy_net.train()  # Retorna ao modo de treinamento
    return torch.argmax(q_vals).item()


def otimizar_modelo():
    if len(memory) < batch_size:
        return

    batch = random.sample(memory, batch_size)
    estados, acoes, recompensas, prox_estados, dones = zip(*batch)

    estados = torch.FloatTensor(np.array(estados)).to(device)
    acoes = torch.LongTensor(acoes).unsqueeze(1).to(device)
    recompensas = torch.FloatTensor(recompensas).to(device)
    prox_estados = torch.FloatTensor(np.array(prox_estados)).to(device)
    dones = torch.FloatTensor(dones).to(device)

    q_vals = policy_net(estados).gather(1, acoes).squeeze()
    with torch.no_grad():
        max_prox_q = target_net(prox_estados).max(1)[0]
        q_alvo = recompensas + gamma * max_prox_q * (1 - dones)

    perda = nn.MSELoss()(q_vals, q_alvo)
    optimizer.zero_grad()
    perda.backward()
    torch.nn.utils.clip_grad_norm_(policy_net.parameters(), max_norm=1.0)
    optimizer.step()


# Treinamento
recompensas_totais = []
melhor_recompensa = -float("inf")
paciencia = 200  # Em vez de 100
contador_paciencia = 0

for episodio in range(episodes):
    estado = env.reset()
    recompensa_total = 0
    done = False
    sem_progresso = 0
    ultima_dist = None

    for _ in range(passos_por_episodio):
        acao = escolher_acao(estado, epsilon)
        proximo_estado, recompensa, done, _ = env.step(acao)

        # Cálculo de distância e recompensas
        dist_atual = np.linalg.norm(
            np.array(proximo_estado[:2]) - np.array(proximo_estado[2:4])
        )
        if ultima_dist is not None:
            if dist_atual < ultima_dist:
                recompensa += 2
                sem_progresso = 0
            else:
                sem_progresso += 1
                recompensa -= 1
        ultima_dist = dist_atual

        if sem_progresso >= 20:
            recompensa -= 20
            sem_progresso = 0

        if done:
            recompensa = 200 if recompensa >= 50 else -30

        memory.append((estado, acao, recompensa, proximo_estado, done))
        estado = proximo_estado
        recompensa_total += recompensa

        if done:
            break

    # Otimização após cada episódio
    if len(memory) >= batch_size:
        otimizar_modelo()

    # Atualizações e verificações
    scheduler.step(recompensa_total)

    epsilon = max(epsilon_min, epsilon * epsilon_decay)
    recompensas_totais.append(recompensa_total)

    # Early stopping e salvamento
    if recompensa_total > melhor_recompensa:
        melhor_recompensa = recompensa_total
        contador_paciencia = 0
        torch.save(policy_net.state_dict(), "melhor_modelo.pth")
    else:
        contador_paciencia += 1

    if contador_paciencia >= paciencia:
        print(f"Early stopping at episode {episodio}")
        break

    # Log e visualização
    if episodio % 50 == 0:
        print(
            f"Episódio {episodio}: Recompensa = {recompensa_total:.1f}, Epsilon = {epsilon:.3f}, LR = {optimizer.param_groups[0]['lr']:.2e}"
        )

        linha_recompensa.set_data(range(len(recompensas_totais)), recompensas_totais)
        if len(recompensas_totais) >= 50:
            media_movel = np.convolve(
                recompensas_totais, np.ones(50) / 50, mode="valid"
            )
            linha_media.set_data(range(49, 49 + len(media_movel)), media_movel)

        ax.relim()
        ax.autoscale_view()
        plt.pause(0.001)

    if episodio % 100 == 0:
        torch.save(policy_net.state_dict(), f"checkpoint_{episodio}.pth")

plt.ioff()
plt.show()
torch.save(policy_net.state_dict(), "modelo_final.pth")
