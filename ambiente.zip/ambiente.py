import numpy as np


class Ambiente:
    def __init__(self, mapa, objetivo=None):
        self.mapa = np.array(mapa)
        self.inicio = (0, 0)
        self.objetivo = (
            objetivo if objetivo is not None else (5, 5)
        )  # Mantém padrão se não fornecido
        self.estado = self.inicio

    def reset(self):
        self.estado = self.inicio
        return self._obter_estado()

    def step(self, acao):
        y, x = self.estado
        movimentos = [(y - 1, x), (y + 1, x), (y, x - 1), (y, x + 1)]
        novo_estado = movimentos[acao]

        # Verificar se o novo estado está dentro dos limites do mapa
        if (
            0 <= novo_estado[0] < self.mapa.shape[0]
            and 0 <= novo_estado[1] < self.mapa.shape[1]
        ):
            if self.mapa[novo_estado] != 1:  # Verificar se não é um obstáculo
                self.estado = novo_estado

        recompensa = -1
        done = False
        if self.estado == self.objetivo:
            recompensa = 200  # Recompensa maior por alcançar o objetivo
            done = True
        else:
            dist_atual = np.linalg.norm(np.array(self.estado) - np.array(self.objetivo))
            recompensa = -1 - dist_atual * 0.1  # Penalidade por distância
            if not (
                0 <= novo_estado[0] < self.mapa.shape[0]
                and 0 <= novo_estado[1] < self.mapa.shape[1]
            ):
                recompensa -= 50  # Penalidade por tentar sair do mapa

        return self._obter_estado(), recompensa, done, {}

    def _obter_estado(self):
        y, x = self.estado
        gy, gx = self.objetivo
        dist_y = gy - y
        dist_x = gx - x

        # Adicionar informações adicionais para garantir 10 elementos
        obstaculos = [
            self._obstaculo(y - 1, x),  # Cima
            self._obstaculo(y + 1, x),  # Baixo
            self._obstaculo(y, x - 1),  # Esquerda
            self._obstaculo(y, x + 1),  # Direita
        ]

        return [y, x, gy, gx, dist_y, dist_x] + obstaculos[:4]  # Total de 10 elementos

    def _obstaculo(self, y, x):
        if 0 <= y < self.mapa.shape[0] and 0 <= x < self.mapa.shape[1]:
            return self.mapa[y, x]
        return 1
