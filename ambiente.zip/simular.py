import pygame
import torch
import numpy as np
import time
from ambiente import Ambiente

# Cores
BRANCO = (255, 255, 255)
PRETO = (0, 0, 0)
AZUL = (0, 0, 255)
VERDE = (0, 255, 0)
VERMELHO = (255, 0, 0)
CINZENTO = (200, 200, 200)


class Simulador:
    def __init__(self, mapa, objetivo, velocidade=5):
        self.mapa = mapa
        self.objetivo = objetivo
        self.velocidade = velocidade
        self.TAMANHO_CELULA = 30

        # Configurações do ambiente
        self.ALTURA_MAPA, self.LARGURA_MAPA = len(mapa), len(mapa[0])
        self.LARGURA = self.LARGURA_MAPA * self.TAMANHO_CELULA
        self.ALTURA = self.ALTURA_MAPA * self.TAMANHO_CELULA

        # Inicialização do Pygame
        pygame.init()
        self.tela = pygame.display.set_mode((self.LARGURA, self.ALTURA + 40))
        pygame.display.set_caption("Simulação do Agente")
        self.font = pygame.font.SysFont(None, 24)
        self.clock = pygame.time.Clock()

        # Estado da simulação
        self.env = Ambiente(mapa, objetivo)
        self.estado = self.env.reset()
        self.rastros = []
        self.stats = {"passos": 0, "recompensa": 0}
        self.paused = False
        self.running = True
        self.colisao = False

        # Carrega o modelo DQN
        self.device = torch.device(
            "mps" if torch.backends.mps.is_available() else "cpu"
        )
        self.modelo = self.carregar_modelo()

    def carregar_modelo(self):
        class DQN(torch.nn.Module):
            def __init__(self, input_dim, output_dim):
                super(DQN, self).__init__()
                self.fc1 = torch.nn.Linear(
                    input_dim, 512
                )  # Deve ser 256, como no treino
                self.fc2 = torch.nn.Linear(512, 256)
                self.fc3 = torch.nn.Linear(256, output_dim)

            def forward(self, x):
                x = torch.relu(self.fc1(x))
                x = torch.relu(self.fc2(x))
                return self.fc3(x)

        modelo = DQN(8, 4).to(self.device)
        modelo.load_state_dict(
            torch.load("modelo_dqn_hard.pth", map_location=self.device)
        )
        modelo.eval()
        return modelo

    def escolher_acao(self, estado):
        t = torch.FloatTensor(estado).unsqueeze(0).to(self.device)
        with torch.no_grad():
            qs = self.modelo(t)
        return torch.argmax(qs).item()

    def desenhar(self):
        self.tela.fill(BRANCO)

        # Desenhar mapa
        for y in range(len(self.mapa)):
            for x in range(len(self.mapa[0])):
                rect = pygame.Rect(
                    x * self.TAMANHO_CELULA,
                    y * self.TAMANHO_CELULA,
                    self.TAMANHO_CELULA,
                    self.TAMANHO_CELULA,
                )
                cor = PRETO if self.mapa[y][x] == 1 else BRANCO
                pygame.draw.rect(self.tela, cor, rect)
                pygame.draw.rect(self.tela, CINZENTO, rect, 1)

        # Desenhar rastros
        for ry, rx in self.rastros:
            pos = (
                rx * self.TAMANHO_CELULA + self.TAMANHO_CELULA // 4,
                ry * self.TAMANHO_CELULA + self.TAMANHO_CELULA // 4,
            )
            pygame.draw.rect(
                self.tela,
                (180, 180, 250),
                (*pos, self.TAMANHO_CELULA // 2, self.TAMANHO_CELULA // 2),
            )

        # Desenhar objetivo e agente
        pygame.draw.rect(
            self.tela,
            VERMELHO,
            (
                self.env.objetivo[1] * self.TAMANHO_CELULA,
                self.env.objetivo[0] * self.TAMANHO_CELULA,
                self.TAMANHO_CELULA,
                self.TAMANHO_CELULA,
            ),
        )

        pygame.draw.rect(
            self.tela,
            AZUL,
            (
                self.env.estado[1] * self.TAMANHO_CELULA,
                self.env.estado[0] * self.TAMANHO_CELULA,
                self.TAMANHO_CELULA,
                self.TAMANHO_CELULA,
            ),
        )

        # Efeito de colisão
        if self.colisao:
            overlay = pygame.Surface((self.LARGURA, self.ALTURA), pygame.SRCALPHA)
            overlay.fill((255, 0, 0, 80))
            self.tela.blit(overlay, (0, 0))

        # HUD com estatísticas
        hud = self.font.render(
            f"Passos: {self.stats['passos']}  Recompensa: {self.stats['recompensa']}",
            True,
            PRETO,
        )
        self.tela.blit(hud, (10, self.ALTURA + 10))

        pygame.display.flip()

    def tratar_eventos(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    self.paused = not self.paused
                elif event.key in (pygame.K_PLUS, pygame.K_KP_PLUS):
                    self.velocidade += 5
                elif event.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
                    self.velocidade = max(1, self.velocidade - 5)

    def executar(self):
        while self.running:
            self.clock.tick(self.velocidade)
            self.tratar_eventos()

            if self.paused:
                continue

            # Executar passo da simulação
            acao = self.escolher_acao(self.estado)
            resultado = self.env.step(acao)

            if len(resultado) == 4:
                proximo_estado, recompensa, feito, self.colisao = resultado
            else:
                proximo_estado, recompensa, feito = resultado
                self.colisao = recompensa <= -10

            self.rastros.append(self.env.estado)
            self.estado = proximo_estado
            self.stats["passos"] += 1
            self.stats["recompensa"] += recompensa

            self.desenhar()

            if feito:
                print("Encomenda encontrada!")
                time.sleep(2)
                self.running = False

        pygame.quit()


def simular(mapa, objetivo, velocidade=5):
    simulador = Simulador(mapa, objetivo, velocidade)
    simulador.executar()
